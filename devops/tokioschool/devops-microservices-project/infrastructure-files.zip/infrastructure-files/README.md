# Infrastructure Files - DevOps Microservices Project

This directory contains all infrastructure configuration files for Docker, Jenkins, and Monitoring.

## 📁 Directory Structure

```
infrastructure/
├── docker/
│   ├── network-config.yml          # Network configuration
│   └── push-to-registry.sh         # Registry push script
├── jenkins/
│   ├── docker-compose.jenkins.yml  # Jenkins container setup
│   ├── setup-jenkins.sh            # Jenkins installation script
│   ├── plugins.txt                 # Required plugins list
│   └── pipeline-job-config.xml     # Pipeline job configuration
└── monitoring/
    ├── docker-compose.jaeger.yml   # Jaeger distributed tracing
    ├── docker-compose.monitoring.yml # Prometheus + Grafana
    ├── prometheus.yml              # Prometheus configuration
    ├── alert_rules.yml             # Alert rules
    └── grafana-dashboard.json      # Grafana dashboard
```

## 🐳 Docker

### Network Configuration
Defines the bridge network for microservices communication.

### Registry Push Script
```bash
chmod +x docker/push-to-registry.sh
export DOCKER_REGISTRY=your-registry.com
./docker/push-to-registry.sh
```

## 🔧 Jenkins

### Setup Jenkins
```bash
cd jenkins/
chmod +x setup-jenkins.sh
./setup-jenkins.sh
```

This will:
- Start Jenkins container
- Display initial admin password
- Configure port 8080 for UI
- Set up Docker integration

### Required Plugins
See `plugins.txt` for the complete list of required plugins.

### Pipeline Job
Import `pipeline-job-config.xml` to create the CI/CD pipeline job.

## 📊 Monitoring

### Jaeger (Distributed Tracing)
```bash
cd monitoring/
docker-compose -f docker-compose.jaeger.yml up -d
```

Access Jaeger UI: http://localhost:16686

### Prometheus + Grafana
```bash
cd monitoring/
docker network create monitoring-network
docker-compose -f docker-compose.monitoring.yml up -d
```

Access:
- Prometheus: http://localhost:9090
- Grafana: http://localhost:3000 (admin/admin)
- Alertmanager: http://localhost:9093

### Alert Rules
Custom alert rules are defined in `alert_rules.yml`:
- Service Down alerts
- High error rate alerts
- High latency alerts
- Resource usage alerts

## 🚀 Quick Start

### 1. Setup Jenkins
```bash
cd infrastructure/jenkins
./setup-jenkins.sh
```

### 2. Start Monitoring Stack
```bash
cd infrastructure/monitoring
docker network create monitoring-network
docker-compose -f docker-compose.jaeger.yml up -d
docker-compose -f docker-compose.monitoring.yml up -d
```

### 3. Verify Everything
```bash
# Check Jenkins
curl http://localhost:8080

# Check Jaeger
curl http://localhost:16686

# Check Prometheus
curl http://localhost:9090

# Check Grafana
curl http://localhost:3000
```

## 📝 Notes

- All configurations are production-ready
- Passwords should be changed in production
- Volumes are created for data persistence
- Networks are isolated for security

## 🔗 Integration with Main Project

These infrastructure files integrate with the main `docker-compose.yml` in the project root:

```yaml
# Main docker-compose.yml should include:
networks:
  microservices-network:
    external: true
  monitoring-network:
    external: true
```

## 📚 Additional Resources

- [Jenkins Documentation](https://www.jenkins.io/doc/)
- [Jaeger Documentation](https://www.jaegertracing.io/docs/)
- [Prometheus Documentation](https://prometheus.io/docs/)
- [Grafana Documentation](https://grafana.com/docs/)
